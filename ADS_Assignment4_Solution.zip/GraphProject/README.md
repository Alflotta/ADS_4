# ADS Assignment 4 – Graphs

## File Structure

```
GraphProject/
  src/
    Graph.java             – Undirected graph with adjacency lists
    DepthFirstSearch.java  – DFS (Task 3a)
    BreadthFirstSearch.java– BFS (Task 3b)
    WeightedGraph.java     – Weighted undirected graph for Dijkstra
    Dijkstra.java          – Dijkstra's shortest path (Task 5)
    Main.java              – Entry point, runs Tasks 3 & 5

Task1_DFS.txt              – Detailed DFS trace (Task 1)
Task2_BFS.txt              – Detailed BFS trace (Task 2)
Task4_Dijkstra.txt         – Dijkstra hand-trace Edinburgh→Dundee (Task 4)
```

## How to Compile & Run

```bash
mkdir out
javac src/*.java -d out
java -cp out Main
```

## Expected Output (Tasks 3 & 5)

Task 3 – DFS visit order : [A, C, B, E, G, F, D]  ✓ matches Task 1
Task 3 – BFS visit order : [A, C, B, D, E, G, F]  ✓ matches Task 2
Task 5 – Shortest path   : Edinburgh → Perth → Dundee (66 miles) ✓ matches Task 4
