import java.util.*;

/**
 * Depth First Search on an undirected Graph.
 * Follows the Sedgewick & Wayne (Algorithms 4th Ed., p.537) style:
 *   marked[] and edgeTo[] arrays, recursive DFS.
 */
public class DepthFirstSearch {

    private final Set<String>         marked  = new LinkedHashSet<>();
    private final Map<String, String> edgeTo  = new LinkedHashMap<>();
    private final List<String>        visited = new ArrayList<>();
    private final String              source;

    public DepthFirstSearch(Graph g, String source) {
        this.source = source;
        dfs(g, source);
    }

    private void dfs(Graph g, String v) {
        marked.add(v);
        visited.add(v);
        System.out.println("  dfs(" + v + ")  →  marked[" + v + "] = true");
        for (String w : g.adjacent(v)) {
            if (!marked.contains(w)) {
                edgeTo.put(w, v);
                System.out.println("    " + v + " → " + w + " (not marked, recurse)");
                dfs(g, w);
            } else {
                System.out.println("    " + v + " → " + w + " (already marked, skip)");
            }
        }
        System.out.println("  return from dfs(" + v + ")");
    }

    /** Returns true if vertex v is reachable from the source. */
    public boolean hasPathTo(String v) {
        return marked.contains(v);
    }

    /** Returns the order in which vertices were first visited. */
    public List<String> visitOrder() {
        return Collections.unmodifiableList(visited);
    }

    /** Returns a shortest path from source to v (in the DFS tree). */
    public Iterable<String> pathTo(String v) {
        if (!hasPathTo(v)) return null;
        Deque<String> path = new ArrayDeque<>();
        for (String x = v; !x.equals(source); x = edgeTo.get(x)) {
            path.push(x);
        }
        path.push(source);
        return path;
    }

    public Map<String, String> edgeTo() {
        return Collections.unmodifiableMap(edgeTo);
    }
}
