import java.util.*;

/**
 * Undirected graph using adjacency lists.
 * Vertices are identified by String labels.
 */
public class Graph {

    private final Map<String, List<String>> adj;

    public Graph() {
        adj = new LinkedHashMap<>();
    }

    /** Add a vertex (if not already present). */
    public void addVertex(String v) {
        adj.putIfAbsent(v, new ArrayList<>());
    }

    /** Add an undirected edge between v and w. */
    public void addEdge(String v, String w) {
        addVertex(v);
        addVertex(w);
        adj.get(v).add(w);
        adj.get(w).add(v);
    }

    /** Return the adjacency list for vertex v. */
    public List<String> adjacent(String v) {
        return adj.getOrDefault(v, Collections.emptyList());
    }

    /** Return all vertices. */
    public Set<String> vertices() {
        return adj.keySet();
    }
}
