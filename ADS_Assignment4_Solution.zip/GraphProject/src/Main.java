import java.util.*;

/**
 * ADS Assignment 4 – Graphs
 *
 * Task 3: DFS and BFS on the graph from Tasks 1 & 2 (source = A).
 * Task 5: Dijkstra's shortest path on the Scottish road network
 *         (Edinburgh → Dundee).
 *
 * Run:  javac src/*.java -d out && java -cp out Main
 */
public class Main {

    public static void main(String[] args) {

        // ================================================================
        // TASK 3 – DFS and BFS (graph from Tasks 1 & 2)
        // ================================================================

        // Build the graph
        // Adjacency lists exactly as given in the assignment:
        //   A: C B D
        //   B: A C E G
        //   C: A B D
        //   D: C A
        //   E: G F B
        //   F: G E
        //   G: F B
        Graph g = new Graph();
        g.addEdge("A", "C");
        g.addEdge("A", "B");
        g.addEdge("A", "D");
        g.addEdge("B", "C");
        g.addEdge("B", "E");
        g.addEdge("B", "G");
        g.addEdge("C", "D");
        g.addEdge("E", "G");
        g.addEdge("E", "F");
        g.addEdge("F", "G");

        // ----------------------------------------------------------------
        // TASK 3a – Depth First Search
        // ----------------------------------------------------------------
        printSeparator("TASK 3 – DFS (source = A)");
        DepthFirstSearch dfs = new DepthFirstSearch(g, "A");

        System.out.println("\n=== DFS Results ===");
        System.out.println("Visit order : " + dfs.visitOrder());
        System.out.println("edgeTo      : " + dfs.edgeTo());
        System.out.println("\nExpected from Task 1 : [A, C, B, E, G, F, D]");
        System.out.println("Match? " + dfs.visitOrder().toString()
                .equals("[A, C, B, E, G, F, D]"));

        // ----------------------------------------------------------------
        // TASK 3b – Breadth First Search
        // ----------------------------------------------------------------
        printSeparator("TASK 3 – BFS (source = A)");
        BreadthFirstSearch bfs = new BreadthFirstSearch(g, "A");

        System.out.println("\n=== BFS Results ===");
        System.out.println("Visit order : " + bfs.visitOrder());
        System.out.println("distTo      : " + bfs.distTo());
        System.out.println("edgeTo      : " + bfs.edgeTo());
        System.out.println("\nExpected from Task 2 : [A, C, B, D, E, G, F]");
        System.out.println("Match? " + bfs.visitOrder().toString()
                .equals("[A, C, B, D, E, G, F]"));

        System.out.println("\n--- Shortest paths from A (BFS) ---");
        for (String v : List.of("B", "C", "D", "E", "F", "G")) {
            System.out.println("A to " + v + " : " + bfs.pathTo(v)
                    + "  (dist=" + bfs.distTo().get(v) + ")");
        }

        // ================================================================
        // TASK 5 – Dijkstra's Algorithm (Scottish road network)
        // ================================================================
        printSeparator("TASK 5 – Dijkstra: Edinburgh → Dundee");

        WeightedGraph scotland = new WeightedGraph();
        scotland.addEdge("Edinburgh", "Stirling",  37);
        scotland.addEdge("Edinburgh", "Perth",     44);
        scotland.addEdge("Edinburgh", "Glasgow",   46);
        scotland.addEdge("Stirling",  "Glasgow",   28);
        scotland.addEdge("Stirling",  "Perth",     35);
        scotland.addEdge("Stirling",  "Dundee",    48);
        scotland.addEdge("Perth",     "Dundee",    22);
        scotland.addEdge("Perth",     "Inverness", 110);
        scotland.addEdge("Dundee",    "Aberdeen",  67);
        scotland.addEdge("Aberdeen",  "Inverness", 105);

        Dijkstra dijkstra = new Dijkstra(scotland, "Edinburgh");

        System.out.println("\n=== Dijkstra Results ===");
        System.out.println("Shortest distances from Edinburgh:");
        for (String city : List.of("Stirling", "Glasgow", "Perth", "Dundee", "Aberdeen", "Inverness")) {
            System.out.printf("  Edinburgh → %-12s : %d miles%n",
                    city, dijkstra.distTo(city));
        }

        List<String> path = dijkstra.pathTo("Dundee");
        System.out.println("\nShortest path Edinburgh → Dundee :");
        System.out.println("  " + String.join(" → ", path));
        System.out.println("  Total distance: " + dijkstra.distTo("Dundee") + " miles");

        System.out.println("\nExpected from Task 4 : Edinburgh → Perth → Dundee (66 miles)");
        System.out.println("Match? " + (path.equals(List.of("Edinburgh", "Perth", "Dundee"))
                && dijkstra.distTo("Dundee") == 66));
    }

    private static void printSeparator(String title) {
        System.out.println("\n" + "=".repeat(60));
        System.out.println(title);
        System.out.println("=".repeat(60));
    }
}
