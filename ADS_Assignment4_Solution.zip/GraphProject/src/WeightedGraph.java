import java.util.*;

/**
 * Weighted undirected graph using adjacency lists.
 * Each edge has an integer weight (distance in miles for Task 5).
 */
public class WeightedGraph {

    /** Simple edge representation: destination + weight. */
    public static class Edge {
        public final String to;
        public final int    weight;
        public Edge(String to, int weight) {
            this.to = to;
            this.weight = weight;
        }
    }

    private final Map<String, List<Edge>> adj;

    public WeightedGraph() {
        adj = new LinkedHashMap<>();
    }

    public void addVertex(String v) {
        adj.putIfAbsent(v, new ArrayList<>());
    }

    /** Add an undirected weighted edge between v and w. */
    public void addEdge(String v, String w, int weight) {
        addVertex(v);
        addVertex(w);
        adj.get(v).add(new Edge(w, weight));
        adj.get(w).add(new Edge(v, weight));
    }

    public List<Edge> adjacent(String v) {
        return adj.getOrDefault(v, Collections.emptyList());
    }

    public Set<String> vertices() {
        return adj.keySet();
    }
}
