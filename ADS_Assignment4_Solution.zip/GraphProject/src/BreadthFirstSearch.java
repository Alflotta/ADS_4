import java.util.*;

/**
 * Breadth First Search on an undirected Graph.
 * Follows the Sedgewick & Wayne (Algorithms 4th Ed., p.539) style:
 *   marked[], edgeTo[], distTo[] arrays, iterative BFS using a Queue.
 */
public class BreadthFirstSearch {

    private final Set<String>         marked  = new LinkedHashSet<>();
    private final Map<String, String> edgeTo  = new LinkedHashMap<>();
    private final Map<String, Integer> distTo = new LinkedHashMap<>();
    private final List<String>        visited = new ArrayList<>();
    private final String              source;

    public BreadthFirstSearch(Graph g, String source) {
        this.source = source;
        bfs(g, source);
    }

    private void bfs(Graph g, String source) {
        Queue<String> queue = new LinkedList<>();
        marked.add(source);
        distTo.put(source, 0);
        queue.add(source);
        System.out.println("  Enqueue " + source + "  distTo[" + source + "]=0");

        while (!queue.isEmpty()) {
            String v = queue.poll();
            visited.add(v);
            System.out.println("\n  Dequeue " + v + "  (distTo=" + distTo.get(v) + ")");
            System.out.println("  Process adjacency list of " + v + ": " + g.adjacent(v));

            for (String w : g.adjacent(v)) {
                if (!marked.contains(w)) {
                    marked.add(w);
                    edgeTo.put(w, v);
                    distTo.put(w, distTo.get(v) + 1);
                    queue.add(w);
                    System.out.println("    " + v + " → " + w
                            + " (not marked, enqueue, distTo[" + w + "]=" + distTo.get(w) + ")");
                } else {
                    System.out.println("    " + v + " → " + w + " (already marked, skip)");
                }
            }
        }
    }

    /** Returns true if vertex v is reachable from the source. */
    public boolean hasPathTo(String v) {
        return marked.contains(v);
    }

    /** Returns the shortest path (fewest edges) from source to v. */
    public Iterable<String> pathTo(String v) {
        if (!hasPathTo(v)) return null;
        Deque<String> path = new ArrayDeque<>();
        for (String x = v; !x.equals(source); x = edgeTo.get(x)) {
            path.push(x);
        }
        path.push(source);
        return path;
    }

    /** Returns the order in which vertices were dequeued (visited). */
    public List<String> visitOrder() {
        return Collections.unmodifiableList(visited);
    }

    public Map<String, Integer> distTo() {
        return Collections.unmodifiableMap(distTo);
    }

    public Map<String, String> edgeTo() {
        return Collections.unmodifiableMap(edgeTo);
    }
}
