import java.util.*;

/**
 * Dijkstra's Shortest Path Algorithm on a WeightedGraph.
 * Uses a priority queue (min-heap) keyed by current best distance.
 * Works for non-negative edge weights.
 */
public class Dijkstra {

    private final Map<String, Integer> distTo  = new LinkedHashMap<>();
    private final Map<String, String>  edgeTo  = new LinkedHashMap<>();
    private final String               source;

    public Dijkstra(WeightedGraph g, String source) {
        this.source = source;

        // Initialise all distances to infinity
        for (String v : g.vertices()) {
            distTo.put(v, Integer.MAX_VALUE);
        }
        distTo.put(source, 0);

        // Priority queue: (distance, vertex)
        // Java's PriorityQueue orders by natural ordering; we use int[] {dist, id}
        // but since vertices are Strings we use a comparator on a custom entry.
        PriorityQueue<String> pq = new PriorityQueue<>(
                Comparator.comparingInt(v -> distTo.getOrDefault(v, Integer.MAX_VALUE))
        );
        pq.add(source);

        System.out.println("  Initialise: distTo[" + source + "] = 0, all others = ∞");
        System.out.println("  Priority queue: [" + source + "]");

        while (!pq.isEmpty()) {
            String u = pq.poll();
            int du = distTo.get(u);
            System.out.println("\n  Extract min: " + u + " (dist=" + du + ")");

            for (WeightedGraph.Edge e : g.adjacent(u)) {
                String v   = e.to;
                int    alt = du + e.weight;
                System.out.print("    Relax " + u + " → " + v
                        + "  (" + du + " + " + e.weight + " = " + alt + ")");
                if (alt < distTo.get(v)) {
                    distTo.put(v, alt);
                    edgeTo.put(v, u);
                    // Re-insert with updated priority (lazy deletion approach)
                    pq.remove(v);
                    pq.add(v);
                    System.out.println("  → IMPROVED  distTo[" + v + "] = " + alt);
                } else {
                    System.out.println("  → no improvement");
                }
            }
        }
    }

    /** Returns the shortest distance from source to v, or -1 if unreachable. */
    public int distTo(String v) {
        int d = distTo.getOrDefault(v, Integer.MAX_VALUE);
        return d == Integer.MAX_VALUE ? -1 : d;
    }

    /** Returns the shortest path from source to v as a list of vertices. */
    public List<String> pathTo(String v) {
        if (distTo(v) == -1) return Collections.emptyList();
        Deque<String> path = new ArrayDeque<>();
        for (String x = v; !x.equals(source); x = edgeTo.get(x)) {
            path.push(x);
        }
        path.push(source);
        return new ArrayList<>(path);
    }
}
